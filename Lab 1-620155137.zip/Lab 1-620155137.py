
def mystery():
 n=input("Enter the last digit of your cellphone number: ")
 n= int(n)
 birth_year=input("Enter the year of your birth: ")
 birth_year=int(birth_year)
 n= ((((n*2)+5)*50)+1772)-birth_year
 return n



def fuzzbiz (x):
   if x%3==0 and x%5==0 :
     return "FuzzBiz"
   elif x%3==0:
        
    return "Fuzz"

   elif x%5==0:
    return "Biz"

   else:
    return "No Fuzz No Biz"


def isLeapYear(x):
    if x%4==0 and x%100!=0:
        return True

    elif x%100==0 and x%400==0:
        return True
    else:
        return False
        

